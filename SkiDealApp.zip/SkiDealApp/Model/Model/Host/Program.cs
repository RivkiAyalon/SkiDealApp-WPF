﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WcfService1;

namespace Host
{
    public class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(WcfService1.Service1));
            host.Open();
            ServiceHost host2 = new ServiceHost(typeof(WcfService1.Client));
            host2.Open();
            Console.WriteLine("the server is running.... do not close this windows");
            Console.ReadLine();

        }
    }
}
