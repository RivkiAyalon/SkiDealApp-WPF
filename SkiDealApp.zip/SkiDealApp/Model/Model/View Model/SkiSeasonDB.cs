﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class SkiSeasonDB:BaseDB
    {
        public SkiSeasonDB() : base("SkiSeason") { }
        public override BaseEntity CreateModel()
        {
            SkiSeason s2 = new SkiSeason();
            s2.CodeSeason = Convert.ToInt32(reader["CodeSeason"]);
            s2.NameSeason = reader["NameSeason"].ToString();
            s2.fromdate = Convert.ToDateTime(reader["fromdate"]);
            s2.untildate = Convert.ToDateTime(reader["untildate"]);
            return s2;

        }
        public List<SkiSeason> GetList()
        {
            return list.ConvertAll(x => (SkiSeason)x);
        }

        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.CodeSeason) + 1;
        }
        
    }
}
