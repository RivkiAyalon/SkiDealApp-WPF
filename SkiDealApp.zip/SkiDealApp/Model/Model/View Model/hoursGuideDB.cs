﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
namespace View_Model
{
    public class hoursGuideDB :BaseDB
    {
        public hoursGuideDB() : base("hoursGuide") { }
        public override BaseEntity CreateModel()
        {
            hoursGuide h = new hoursGuide();
            h.workhoursCode = Convert.ToInt32(reader["workhoursCode"]);
            h.IdGuide =MyDB.Guide.GetByCode( Convert.ToInt32(reader["IdGuide"]));
            h.Day =reader["Day"].ToString();
         
            return h;

        }
        public List<hoursGuide> GetList()
        {
            return list.ConvertAll(x => (hoursGuide)x);
        }
        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.workhoursCode) + 1;
        }
    }
}
