﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using Model;
using System.IO;
using ViewModel;

namespace View_Model
{
    public abstract class BaseDB
    {
        protected List<BaseEntity> list;
       
        OleDbConnection connection;
        OleDbCommand command;
        protected OleDbDataReader reader;

        string tableName;

        protected List<BaseEntity> AddedItems = new List<BaseEntity>();
        protected List<BaseEntity> ChangedItems = new List<BaseEntity>();
        protected List<BaseEntity> DeletedItems = new List<BaseEntity>();

        public BaseDB(string TableName)
        {
            tableName = TableName;
            connection = new OleDbConnection(@"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = '" + GetDBPath() + "'");
            command = new OleDbCommand("select * from " + TableName);
            list = new List<BaseEntity>();
            Connect();
        }
     
        public void Connect()
        {

            if (list.Count() == 0)
            {
                command = new OleDbCommand("select * from " + tableName);
                command.Connection = connection;
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(CreateModel());
                }
                connection.Close();
            }

        }

        private string GetDBPath()
        {
            string path =Directory.GetCurrentDirectory();
            string[] arr = path.Split('\\');
            path = "";
            for (int i = 0; i < arr.Length - 3; i++)
            {
                path += arr[i] + "\\";
            }
            path += "Data\\Database1.accdb";//להחליף את שם מסד הנתונים לפי שם האקסס שלך
            return path;
        }

        public abstract BaseEntity CreateModel();


        public void Add(BaseEntity item)
        {
            AddedItems.Add(item);
        }
        public void Update(BaseEntity item)
        {
            ChangedItems.Add(item);
        }
        public void Delete(BaseEntity item)
        {
            DeletedItems.Add(item);
        }

        public void SaveChanges()
        {
            command.Connection = connection;
            connection.Open();
            foreach (var item in AddedItems)
            {
                command.CommandText = SQLBuilder.InsertSQL(item);
                command.ExecuteNonQuery();
            }
            AddedItems.Clear();

            foreach (var item in ChangedItems)
            {
                command.CommandText = SQLBuilder.UpdateSQL(item);
                command.ExecuteNonQuery();
            }
            ChangedItems.Clear();
            foreach (var item in DeletedItems)
            {
                command.CommandText = SQLBuilder.DeleteSQL(item);
                command.ExecuteNonQuery();
            }
            DeletedItems.Clear();
            list = new List<BaseEntity>();
            connection.Close();

            Connect();
        }

        public virtual int GetNextKey()
        {
            return 0;
        }
    }

}
