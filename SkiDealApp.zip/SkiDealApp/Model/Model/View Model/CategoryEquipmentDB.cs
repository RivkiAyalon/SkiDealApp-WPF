﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class CategoryEquipmentDB:BaseDB
    {
        public CategoryEquipmentDB() : base("CategoryEquipment") { }
        public override BaseEntity CreateModel()
        {
            CategoryEquipment ca = new CategoryEquipment();
            ca.CodeCategory = Convert.ToInt32(reader["CodeCategory"]);
            ca.NameCategory = reader["NameCategory"].ToString();
          
            return ca;

        }
        public List<CategoryEquipment> GetList()
        {
            return list.ConvertAll(x => (CategoryEquipment)x);
        }
        public CategoryEquipment GetByCode(int Category)
        {
            return GetList().FirstOrDefault(x => x.CodeCategory == Category);
        }

        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.CodeCategory) + 1;
        }
    }
}
