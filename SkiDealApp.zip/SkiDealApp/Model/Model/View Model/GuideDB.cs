﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class GuideDB : BaseDB
    {
        public GuideDB() : base("Guide") { }
        public override BaseEntity CreateModel()
        {
            Guide g = new Guide();
            g.IdGuide = Convert.ToInt32(reader["IdGuide"]);
            g.NameGuide = reader["NameGuide"].ToString();
            g.legion = reader["legion"].ToString();
            g.Phone = Convert.ToInt32(reader["Phone"]);
            g.Mail = reader["Mail"].ToString();
            return g;

        }
        public List<Guide> GetList()
        {
            return list.ConvertAll(x => (Guide)x);
        }

        public Guide GetByCode(int id)
        {
            return GetList().FirstOrDefault(x => x.IdGuide == id);
        }
        
    }
}
