﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class SubscribeDB:BaseDB
    {
        public SubscribeDB() : base("Subscribe") { }
        public override BaseEntity CreateModel()
        {
            Subscribe s3 = new Subscribe();
            s3.CodeSubscribe = Convert.ToInt32(reader["CodeSubscribe"]);
            s3.IdCustumer = MyDB.Castumer.GetByCode(Convert.ToInt32(reader["IdCustumer"]));
            s3.fromDate = Convert.ToDateTime(reader["fromDate"]);
            s3.untilDate = Convert.ToDateTime(reader["untilDate"]);
            s3.Price = Convert.ToInt32(reader["Price"]);
            s3.Equipmentrental = Convert.ToBoolean(reader["Equipmentrental"]);
            s3.Guide = Convert.ToBoolean(reader["Guide"]);
            return s3;
        }
        public List<Subscribe> GetList()
        {
            return list.ConvertAll(x => (Subscribe)x);
        }

        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.CodeSubscribe) + 1;
        }

    }
}
