﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace View_Model
{
    public class MyDB
    {


        public static CastumerDB Castumer = new CastumerDB();
        public static CategoryEquipmentDB CategoryEquipment = new CategoryEquipmentDB();
       
        public static GuideDB Guide = new GuideDB();
        public static hoursGuideDB hoursGuide = new hoursGuideDB();
        public static LogInToTheSiteDB LogInToTheSite = new LogInToTheSiteDB();
        public static skiEquipmentDB skiEquipment = new skiEquipmentDB();
        public static SkiSeasonDB SkiSeason = new SkiSeasonDB();
        public static SubscribeDB Subscribe = new SubscribeDB();
        public static DetailsRentDB DetailsRent = new DetailsRentDB();





    }
}
