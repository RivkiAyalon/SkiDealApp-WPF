﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class skiEquipmentDB : BaseDB
    {
        public skiEquipmentDB() : base("skiEquipment") { }
        public override BaseEntity CreateModel()
        {
            skiEquipment s = new skiEquipment();
            s.CodeEquipment = Convert.ToInt32(reader["CodeEquipment"]);
            s.NameEquipment = reader["NameEquipment"].ToString();
            s.Category = MyDB.CategoryEquipment.GetByCode(Convert.ToInt32(reader["Category"]));
            s.Size = Convert.ToInt32(reader["Size"]);
            s.Right = Convert.ToBoolean(reader["Right"]);
            s.Free = Convert.ToBoolean(reader["Free"]);
            return s;

        }
        public List<skiEquipment> GetList()
        {
            return list.ConvertAll(x => (skiEquipment)x);
        }

        public skiEquipment GetByCode(int id)
        {
            return GetList().FirstOrDefault(x => x.CodeEquipment == id);
        }

        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.CodeEquipment) + 1;
        }
    }
}
