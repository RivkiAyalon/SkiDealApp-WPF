﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class LogInToTheSiteDB:BaseDB
    {
        public LogInToTheSiteDB() : base("LogInToTheSite") { }
        public override BaseEntity CreateModel()
        {
            LogInToTheSite l = new LogInToTheSite();
            l.CodeEntery = Convert.ToInt32(reader["CodeEntery"]);
            l.IdCustumer = MyDB.Castumer.GetByCode(Convert.ToInt32(reader["IdCustumer"])); 
            l.Guide = MyDB.Guide.GetByCode(Convert.ToInt32(reader["Guide"]));
            l.Date1 = Convert.ToDateTime(reader["Date1"].ToString());
            l.fromtime = Convert.ToDateTime(reader["fromtime"].ToString());
            l.untiltime = Convert.ToDateTime(reader["untiltime"].ToString());
            return l;

        }
        public List<LogInToTheSite> GetList()
        {
            return list.ConvertAll(x => (LogInToTheSite)x);
        }
        public LogInToTheSite GetByCode(int CodeEquipment)
        {
            return GetList().FirstOrDefault(x => x.CodeEntery == CodeEquipment);
        }

        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.CodeEntery) + 1;
        }
    }
}
