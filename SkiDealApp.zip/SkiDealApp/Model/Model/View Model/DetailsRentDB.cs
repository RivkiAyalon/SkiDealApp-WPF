﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public class DetailsRentDB:BaseDB
    {
        public DetailsRentDB() : base("DetailsRent") { }
        public override BaseEntity CreateModel()
        {
            DetailsRent d = new DetailsRent();
            d.CodeEquipment = MyDB.skiEquipment.GetByCode(Convert.ToInt32(reader["CodeEquipment"]));
            d.CodeEntery = MyDB.LogInToTheSite.GetByCode(Convert.ToInt32(reader["CodeEntery"]));
            d.Return2 = Convert.ToBoolean(reader["Return2"]);
            return d;

        }
        public List<DetailsRent> GetList()
        {
            return list.ConvertAll(x => (DetailsRent)x);
        }
       
    }
}
