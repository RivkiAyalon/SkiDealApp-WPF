﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace View_Model
{
    public   class CastumerDB :BaseDB
    {
        public CastumerDB() : base("Castumer") { }
        public override BaseEntity CreateModel()
        {
            Castumer c =new Castumer();
            c.ID=Convert.ToInt32(reader["ID"]);
            c.FirstName =reader["FirstName"].ToString();
            c.LastName = reader["LastName"].ToString();
            c.Phone = Convert.ToInt32(reader["Phone"]);
            c.Mail =reader["Mail"].ToString();
            c.BirthDate = Convert.ToDateTime(reader["BirthDate"]);
            c.SizeShoes = Convert.ToInt32(reader["SizeShoes"]);
            c.High = Convert.ToInt32(reader["High"]);
            c.Weight = Convert.ToInt32(reader["Weight"]);
            c.Passcode =reader["Passcode"].ToString();
            return c;

        }
        public List<Castumer> GetList()
        {
            return list.ConvertAll(x => (Castumer)x);
        }
        public Castumer GetByCode(int CodeSeasIdCustumeron)
        {
            return GetList().FirstOrDefault(x => x.ID == CodeSeasIdCustumeron);
        }
        public override int GetNextKey()
        {
            if (GetList().Count == 0)
                return 1;
            return GetList().Max(x => x.ID) + 1;
        }
    }
}
