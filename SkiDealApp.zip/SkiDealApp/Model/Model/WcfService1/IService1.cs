﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Model;
using ViewModel;

namespace WcfService1
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        void AddCustomer(Castumer c);

        [OperationContract]
        void DeleteCustomer(Castumer c);
        [OperationContract]
        void UpdateCustomer(Castumer c);
        [OperationContract]
        List<Castumer> GetCastumer();

        [OperationContract]
        void AddCategoryEquipment(CategoryEquipment ce);

        [OperationContract]
        void DeleteCategoryEquipment(CategoryEquipment ce);
        [OperationContract]
        void UpdateCategoryEquipment(CategoryEquipment ce);
        [OperationContract]
        List<CategoryEquipment> GetCategoryEquipment();

        [OperationContract]
        void AddDetailsRent(DetailsRent d);

        [OperationContract]
        void DeleteDetailsRent(DetailsRent d);
        [OperationContract]
        void UpdateDetailsRent(DetailsRent d);
        [OperationContract]
        List<DetailsRent> GetDetailsRent();

        [OperationContract]
        void AddGuide(Guide g);

        [OperationContract]
        void DeleteGuide(Guide g);
        [OperationContract]
        void UpdateGuide(Guide g);
        [OperationContract]
        List<Guide> GetGuide();


        [OperationContract]
        void AddhoursGuide(hoursGuide hg);

        [OperationContract]
        void DeletehoursGuide(hoursGuide hg);
        [OperationContract]
        void UpdatehoursGuide(hoursGuide hg);
        [OperationContract]
        List<hoursGuide> GethoursGuide();

        [OperationContract]
        void AddLogInToTheSite(LogInToTheSite l);

        [OperationContract]
        void DeleteLogInToTheSite(LogInToTheSite l);
        [OperationContract]
        void UpdateLogInToTheSite(LogInToTheSite l);
        [OperationContract]
        List<LogInToTheSite> GetLogInToTheSite();

        [OperationContract]
        void AddskiEquipment(skiEquipment s);

        [OperationContract]
        void DeleteskiEquipment(skiEquipment s);
        [OperationContract]
        void UpdateskiEquipment(skiEquipment s);
        [OperationContract]
        List<skiEquipment> GetskiEquipment();

        [OperationContract]
        void AddSkiSeason(SkiSeason ss);

        [OperationContract]
        void DeleteSkiSeason(SkiSeason ss);
        [OperationContract]
        void UpdateSkiSeason(SkiSeason ss);
        [OperationContract]
        List<SkiSeason> GetSkiSeason();

        [OperationContract]
        void AddSubscribe(Subscribe s2);

        [OperationContract]
        void DeleteSubscribe(Subscribe s2);
        [OperationContract]
        void UpdateSubscribe(Subscribe s2);
        [OperationContract]
        List<Subscribe> GetSubscribe();

    }
}
