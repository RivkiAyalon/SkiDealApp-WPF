﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using View_Model;
using ViewModel;


namespace WcfService1
{
    public class Client : IClient
    {
        //Castumer
        public void AddCustomer(Castumer c)
        {

            MyDB.Castumer.Add(c);
            MyDB.Castumer.SaveChanges();

        }
        public void UpdateCustomer(Castumer c)
        {
            MyDB.Castumer.Update(c);
            MyDB.Castumer.SaveChanges();
        }
        public void DeleteCustomer(Castumer c)
        {
            MyDB.Castumer.Delete(c);
            MyDB.Castumer.SaveChanges();
        }
        public List<Castumer> GetCastumer()
        {
            return MyDB.Castumer.GetList().OrderBy(x => x.FirstName).ToList();
        }
        //CategoryEquipment
        public void AddCategoryEquipment(CategoryEquipment ce)
        {
            ce.CodeCategory = MyDB.CategoryEquipment.GetNextKey();
            MyDB.CategoryEquipment.Add(ce);
            MyDB.CategoryEquipment.SaveChanges();

        }
        public void UpdateCategoryEquipment(CategoryEquipment c)
        {
            MyDB.CategoryEquipment.Update(c);
            MyDB.CategoryEquipment.SaveChanges();
        }
        public void DeleteCategoryEquipment(CategoryEquipment c)
        {
            MyDB.CategoryEquipment.Delete(c);
            MyDB.CategoryEquipment.SaveChanges();
        }

        public List<CategoryEquipment> GetCategoryEquipment()
        {
            return MyDB.CategoryEquipment.GetList().OrderBy(x => x.NameCategory).ToList();
        }

        public void AddGuide(Guide g)
        {
            MyDB.Guide.Add(g);
            MyDB.Guide.SaveChanges();

        }
        public void UpdateGuide(Guide g)
        {
            MyDB.Guide.Update(g);
            MyDB.Guide.SaveChanges();
        }
        public void DeleteGuide(Guide g)
        {
            MyDB.Guide.Delete(g);
            MyDB.Guide.SaveChanges();
        }

        public List<Guide> GetGuide()
        {
            return MyDB.Guide.GetList().OrderBy(x => x.NameGuide).ToList();
        }
        public void AddhoursGuide(hoursGuide hg)
        {
            hg.workhoursCode = MyDB.hoursGuide.GetNextKey();
            MyDB.hoursGuide.Add(hg);
            MyDB.hoursGuide.SaveChanges();

        }
        public void UpdatehoursGuide(hoursGuide hg)
        {
            MyDB.hoursGuide.Update(hg);
            MyDB.hoursGuide.SaveChanges();
        }
        public void DeletehoursGuide(hoursGuide hg)
        {
            MyDB.hoursGuide.Delete(hg);
            MyDB.hoursGuide.SaveChanges();
        }

        public List<hoursGuide> GethoursGuide()
        {
            return MyDB.hoursGuide.GetList().OrderBy(x => x.IdGuide).ToList();
        }



        public void AddLogInToTheSite(LogInToTheSite l)
        {
            l.CodeEntery = MyDB.LogInToTheSite.GetNextKey();
            l.Guide = MyDB.Guide.GetByCode(14725836);
            MyDB.LogInToTheSite.Add(l);
            MyDB.LogInToTheSite.SaveChanges();

        }
        public void UpdateLogInToTheSite(LogInToTheSite l)
        {
            MyDB.LogInToTheSite.Update(l);
            MyDB.LogInToTheSite.SaveChanges();
        }
        public void DeleteLogInToTheSite(LogInToTheSite l)
        {
            MyDB.LogInToTheSite.Delete(l);
            MyDB.LogInToTheSite.SaveChanges();
        }



        //Subscribe
        public void AddSubscribe(Subscribe s2)
        {
            s2.CodeSubscribe = MyDB.Subscribe.GetNextKey();
            MyDB.Subscribe.Add(s2);
            MyDB.Subscribe.SaveChanges();

        }
        public void UpdateSubscribe(Subscribe s2)
        {
            MyDB.Subscribe.Update(s2);
            MyDB.Subscribe.SaveChanges();
        }
        public void DeleteSubscribe(Subscribe s2)
        {
            MyDB.Subscribe.Delete(s2);
            MyDB.Subscribe.SaveChanges();
        }


        public List<hoursGuide> GetDaysWorkForGuide(Guide g)
        {
            return MyDB.hoursGuide.GetList().Where(x => x.IdGuide.IdGuide == g.IdGuide).OrderBy(x => x.workhoursCode).ToList();
        }
        public List<Guide> availbeguides(DateTime date)
        {
            int d = Convert.ToInt32(date.DayOfWeek);
            string[] daysName = new string[] { "ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי" };
            List<Guide> guides = MyDB.hoursGuide.GetList().Where(x => x.Day == daysName[d]).Select(x => x.IdGuide).ToList();
            return guides;
        }

        public List<Subscribe> GetSubscribes()
        {
            return MyDB.Subscribe.GetList();
        }

        public Subscribe GetSubscribeByCustomer(Castumer castumer)
        {
            return MyDB.Subscribe.GetList().FirstOrDefault(x => x.IdCustumer.ID == castumer.ID);
        }

        public skiEquipment GetSkiEquipmentByCaterory(int equipment, Castumer castumer)
        {
            if (equipment == 1)
                return MyDB.skiEquipment.GetList().FirstOrDefault(x => x.Category.CodeCategory == 1 && x.Free);
            if (equipment == 2)
                return MyDB.skiEquipment.GetList().FirstOrDefault(x => x.Category.CodeCategory == 2 && x.Free);
            if (equipment == 3)
                return MyDB.skiEquipment.GetList().FirstOrDefault(x => x.Category.CodeCategory == 3 && x.Free);
            else
                return MyDB.skiEquipment.GetList().FirstOrDefault(x => x.Category.CodeCategory == 4 && x.Free && x.Size == castumer.SizeShoes);
        }

        public void AddDetailsRent(DetailsRent d)
        {
            MyDB.DetailsRent.Add(d);
            MyDB.DetailsRent.SaveChanges();
        }

        public void UpdateskiEquipment(skiEquipment se)
        {
            MyDB.skiEquipment.Update(se);
            MyDB.skiEquipment.SaveChanges();
        }
    }
}
