﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.ServiceModel;
    
namespace WcfService1
{
    [ServiceContract]
    public interface IClient
    {
        [OperationContract]
        void AddCustomer(Castumer c);

        [OperationContract]
        void DeleteCustomer(Castumer c);
        [OperationContract]
        void UpdateCustomer(Castumer c);
        [OperationContract]
        List<Castumer> GetCastumer();

        [OperationContract]
        void AddCategoryEquipment(CategoryEquipment ce);

        [OperationContract]
        void DeleteCategoryEquipment(CategoryEquipment ce);
        [OperationContract]
        void UpdateCategoryEquipment(CategoryEquipment ce);
        [OperationContract]
        List<CategoryEquipment> GetCategoryEquipment();

        [OperationContract]
        void AddGuide(Guide g);

        [OperationContract]
        void DeleteGuide(Guide g);
        [OperationContract]
        void UpdateGuide(Guide g);
        [OperationContract]
        List<Guide> GetGuide();



        [OperationContract]
        void AddhoursGuide(hoursGuide hg);

        [OperationContract]
        void DeletehoursGuide(hoursGuide hg);
        [OperationContract]
        void UpdatehoursGuide(hoursGuide hg);
        [OperationContract]
        List<hoursGuide> GethoursGuide();


        [OperationContract]
        void AddLogInToTheSite(LogInToTheSite l);

        [OperationContract]
        void DeleteLogInToTheSite(LogInToTheSite l);
        [OperationContract]
        void UpdateLogInToTheSite(LogInToTheSite l);
        [OperationContract]



        void AddSubscribe(Subscribe s2);

        [OperationContract]
        void DeleteSubscribe(Subscribe s2);
        [OperationContract]
        void UpdateSubscribe(Subscribe s2);
         [OperationContract]
        List<hoursGuide> GetDaysWorkForGuide(Guide g);

        [OperationContract]
        List<Guide> availbeguides(DateTime date);
        [OperationContract]
        List<Subscribe> GetSubscribes(); 
        [OperationContract]
        Subscribe GetSubscribeByCustomer(Castumer castumer);

        [OperationContract]
        skiEquipment GetSkiEquipmentByCaterory(int category, Castumer castumer);

        [OperationContract]
        void AddDetailsRent(DetailsRent d);
        [OperationContract]
        void UpdateskiEquipment(skiEquipment s);
    }
}
