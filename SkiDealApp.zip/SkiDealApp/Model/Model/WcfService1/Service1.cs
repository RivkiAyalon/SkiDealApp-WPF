﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using View_Model;

namespace WcfService1
{
    public class Service1 : IService1
    {
        //Castumer
        public void AddCustomer(Castumer c)
        {
            MyDB.Castumer.Add(c);
            MyDB.Castumer.SaveChanges();

        }
        public void UpdateCustomer(Castumer c)
        {
            MyDB.Castumer.Update(c);
            MyDB.Castumer.SaveChanges();
        }
        public void DeleteCustomer(Castumer c)
        {
            MyDB.Castumer.Delete(c);
            MyDB.Castumer.SaveChanges();
        }

        public List<Castumer> GetCastumer()
        {
            return MyDB.Castumer.GetList().OrderBy(x => x.FirstName).ToList();
        }

        //CategoryEquipment
        public void AddCategoryEquipment(CategoryEquipment ce)
        {
            ce.CodeCategory=MyDB.CategoryEquipment.GetNextKey();
            MyDB.CategoryEquipment.Add(ce);
            MyDB.CategoryEquipment.SaveChanges();

        }
        public void UpdateCategoryEquipment(CategoryEquipment c)
        {
            MyDB.CategoryEquipment.Update(c);
            MyDB.CategoryEquipment.SaveChanges();
        }
        public void DeleteCategoryEquipment(CategoryEquipment c)
        {
            MyDB.CategoryEquipment.Delete(c);
            MyDB.CategoryEquipment.SaveChanges();
        }

        public List<CategoryEquipment> GetCategoryEquipment()
        {
            return MyDB.CategoryEquipment.GetList().OrderBy(x => x.NameCategory).ToList();
        }
        //DetailsRent
    
        public void UpdateDetailsRent(DetailsRent dr)
        {
            MyDB.DetailsRent.Update(dr);
            MyDB.DetailsRent.SaveChanges();

            if(dr.Return2==true)
            {
                dr.CodeEquipment.Free = true;
                MyDB.skiEquipment.Update(dr.CodeEquipment);
                MyDB.skiEquipment.SaveChanges();
            }
        }
        public void DeleteDetailsRent(DetailsRent dr)
        {
            MyDB.DetailsRent.Delete(dr);
            MyDB.DetailsRent.SaveChanges();
        }

        public List<DetailsRent> GetDetailsRent()
        {
            return MyDB.DetailsRent.GetList().OrderBy(x => x.Return2).ToList();
        }
        //Guide
        public void AddGuide(Guide g)
        {
            MyDB.Guide.Add(g);
            MyDB.Guide.SaveChanges();

        }
        public void UpdateGuide(Guide g)
        {
            MyDB.Guide.Update(g);
            MyDB.Guide.SaveChanges();
        }
        public void DeleteGuide(Guide g)
        {
            MyDB.Guide.Delete(g);
            MyDB.Guide.SaveChanges();
        }

        public List<Guide> GetGuide() => MyDB.Guide.GetList().OrderBy(x => x.NameGuide).ToList();
        //hoursGuide
        public void AddhoursGuide(hoursGuide hg)
        {
            hg.workhoursCode = MyDB.hoursGuide.GetNextKey();
            MyDB.hoursGuide.Add(hg);
            MyDB.hoursGuide.SaveChanges();

        }
        public void UpdatehoursGuide(hoursGuide hg)
        {
            MyDB.hoursGuide.Update(hg);
            MyDB.hoursGuide.SaveChanges();
        }
        public void DeletehoursGuide(hoursGuide hg)
        {
            MyDB.hoursGuide.Delete(hg);
            MyDB.hoursGuide.SaveChanges();
        }

        public List<hoursGuide> GethoursGuide()
        {
            return MyDB.hoursGuide.GetList().OrderBy(x => x.IdGuide).ToList();
        }
        //LogInToTheSite
        public void AddLogInToTheSite(LogInToTheSite l)
        {
            l.CodeEntery = MyDB.LogInToTheSite.GetNextKey();
            MyDB.LogInToTheSite.Add(l);
            MyDB.LogInToTheSite.SaveChanges();

        }
        public void UpdateLogInToTheSite(LogInToTheSite l)
        {
            MyDB.LogInToTheSite.Update(l);
            MyDB.LogInToTheSite.SaveChanges();
        }
        public void DeleteLogInToTheSite(LogInToTheSite l)
        {
            MyDB.LogInToTheSite.Delete(l);
            MyDB.LogInToTheSite.SaveChanges();
        }

        public List<LogInToTheSite> GetLogInToTheSite()
        {
            return MyDB.LogInToTheSite.GetList().OrderBy(x => x.CodeEntery).ToList();
        }
        //skiEquipment
        public void AddskiEquipment(skiEquipment se)
        {
            se.CodeEquipment = MyDB.skiEquipment.GetNextKey();
            MyDB.skiEquipment.Add(se);
            MyDB.skiEquipment.SaveChanges();

        }
        public void UpdateskiEquipment(skiEquipment se)
        {
            MyDB.skiEquipment.Update(se);
            MyDB.skiEquipment.SaveChanges();
        }
        public void DeleteskiEquipment(skiEquipment se)
        {
            MyDB.skiEquipment.Delete(se);
            MyDB.skiEquipment.SaveChanges();
        }

        public List<skiEquipment> GetskiEquipment()
        {
            return MyDB.skiEquipment.GetList().OrderBy(x => x.NameEquipment).ToList();
        }
        //SkiSeason
        public void AddSkiSeason(SkiSeason ss)
        {
            ss.CodeSeason = MyDB.SkiSeason.GetNextKey();
            MyDB.SkiSeason.Add(ss);
            MyDB.SkiSeason.SaveChanges();

        }
        public void UpdateSkiSeason(SkiSeason ss)
        {
            MyDB.SkiSeason.Update(ss);
            MyDB.SkiSeason.SaveChanges();
        }
        public void DeleteSkiSeason(SkiSeason ss)
        {
            MyDB.SkiSeason.Delete(ss);
            MyDB.SkiSeason.SaveChanges();
        }

        public List<SkiSeason> GetSkiSeason()
        {
            return MyDB.SkiSeason.GetList().OrderBy(x => x.NameSeason).ToList();
        }
        //Subscribe
        public void AddSubscribe(Subscribe s2)
        {
            s2.CodeSubscribe = MyDB.Subscribe.GetNextKey();
            MyDB.Subscribe.Add(s2);
            MyDB.Subscribe.SaveChanges();

        }
        public void UpdateSubscribe(Subscribe s2)
        {
            MyDB.Subscribe.Update(s2);
            MyDB.Subscribe.SaveChanges();
        }
        public void DeleteSubscribe(Subscribe s2)
        {
            MyDB.Subscribe.Delete(s2);
            MyDB.Subscribe.SaveChanges();
        }

        public List<Subscribe> GetSubscribe()
        {
            return MyDB.Subscribe.GetList().OrderBy(x => x.CodeSubscribe).ToList();
        }

        public void AddDetailsRent(DetailsRent d)
        {
            MyDB.DetailsRent.Add(d);
            MyDB.DetailsRent.SaveChanges();

            d.CodeEquipment.Free = false;
            MyDB.skiEquipment.Update(d.CodeEquipment);
            MyDB.skiEquipment.SaveChanges();
        }
    }
}
