﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class skiEquipment : BaseEntity
    {
        public int CodeEquipment { get; set; }
        public string NameEquipment { get; set; }
        public CategoryEquipment Category { get; set; }
        public int Size { get; set; }
        public bool Right { get; set; }
        public bool Free { get; set; }
        public override string GetTableName()
        {
            return "skiEquipment"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "CodeEquipment" }; //שמ/ות השדה מפת
        }
    }
}
