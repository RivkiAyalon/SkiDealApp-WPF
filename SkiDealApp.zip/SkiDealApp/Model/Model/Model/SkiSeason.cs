﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class SkiSeason : BaseEntity
    {
        public int CodeSeason { get; set; }
        public string NameSeason { get; set; }
        public DateTime fromdate { get; set; }
        public DateTime untildate { get; set; }
        public override string GetTableName()
        {
            return "SkiSeason"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "CodeSeason" }; //שמ/ות השדה מפת
        }
    }
}
