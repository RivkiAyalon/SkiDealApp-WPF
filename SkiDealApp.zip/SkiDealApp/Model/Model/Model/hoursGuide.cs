﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class hoursGuide : BaseEntity
    {
        public int workhoursCode { get; set; }
        public int IdGuide { get; set; }
        public DateTime Day { get; set; }
        public DateTime fromtime { get; set; }
        public DateTime untiltime { get; set; }
        public override string GetTableName()
        {
            return "hoursGuide"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "workhoursCode" }; //שמ/ות השדה מפת
        }
    }
}
