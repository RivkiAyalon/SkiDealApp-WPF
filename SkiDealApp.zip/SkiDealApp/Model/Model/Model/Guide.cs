﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Guide : BaseEntity
    {
        public int IdGuide { get; set; }
        public string NameGuide { get; set; }
        public string legion { get; set; }
        public int Phone { get; set; }
        public string Mail { get; set; }
        public override string GetTableName()
        {
            return "Guide"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "IdGuide" }; //שמ/ות השדה מפת
        }
    }
}
