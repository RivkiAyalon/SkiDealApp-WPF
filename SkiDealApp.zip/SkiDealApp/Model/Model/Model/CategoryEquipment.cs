﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CategoryEquipment : BaseEntity
    {
        public int CodeCategory { get; set; }
        public string NameCategory { get; set; }
        public override string GetTableName()
        {
            return "CategoryEquipment"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "CodeCategory" }; //שמ/ות השדה מפתח
        }
    }
}
