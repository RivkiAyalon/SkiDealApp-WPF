﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class DetailsRent : BaseEntity
    {
        public int CodeEquipment { get; set; }
        public int CodeEntery { get; set; }
        public bool Return2 { get; set; }
        public override string GetTableName()
        {
            return "DetailsRent"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "CodeEquipment" }; //שמ/ות השדה מפתח
            return new string[] { "CodeEntery" }; //שמ/ות השדה מפתח
        }
    }
}
