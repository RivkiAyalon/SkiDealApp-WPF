﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Subscribe: BaseEntity
    {
        public int CodeSubscribe { get; set; }
        public int CodeSeasIdCustumeron { get; set; }
        public DateTime fromDate { get; set; }
        public DateTime untilDate { get; set; }
        public int Price { get; set; }
        public bool Equipmentrental { get; set; }
        public bool Guide { get; set; }
        public override string GetTableName()
        {
            return "Subscribe"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "CodeSubscribe" }; //שמ/ות השדה מפת
        }
    }
}
