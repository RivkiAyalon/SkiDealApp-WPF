﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class LogInToTheSite : BaseEntity
    {
        public int CodeEntery { get; set; }
        public int IdCustumer { get; set; }
        public int Guide { get; set; }
        public DateTime Date1 { get; set; }
        public DateTime fromtime { get; set; }
        public DateTime untiltime { get; set; }
        public override string GetTableName()
        {
            return "LogInToTheSite"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "CodeEntery" }; //שמ/ות השדה מפת
        }
    }
}
