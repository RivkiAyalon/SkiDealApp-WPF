﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Castumer:BaseEntity
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Phone { get; set; }
        public string Mail { get; set; }
        public DateTime BirthDate { get; set; }
        public int SizeShoes { get; set; }
        public int High { get; set; }
        public int Weight { get; set; }
        public string Passcode { get; set; }
        public override string GetTableName()
        {
            return "Castumer"; //שם הטבלה
        }
        public override string[] GetKeyFileds()
        {
            return new string[] { "ID" }; //שמ/ות השדה מפתח
        }
    }
}
