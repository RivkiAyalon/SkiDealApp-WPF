﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ClientApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BlankPage1 : Page
    {
        ServiceClient.Castumer thisUser;
        StatusPage statusPage;
        public BlankPage1()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
           
           
                if(e.Parameter==null)
                statusPage =StatusPage.Add;  
                else
            {
                thisUser = e.Parameter as ServiceClient.Castumer;
                FillFromFields();
            }
                
        }

        private void FillFromFields()
        {
            numAd.Text = thisUser.ID.ToString();
            nameCas.Text = thisUser.FirstName;
            lastnameCas.Text = thisUser.LastName;
            phone.Text = thisUser.Phone.ToString();  
            email.Text = thisUser.Mail;
            DateBD.Date = thisUser.BirthDate;
            shoesSize.Text = thisUser.SizeShoes.ToString();
            heightCas.Text = thisUser.High.ToString();
            wightCas.Text = thisUser.Weight.ToString();
            passwordCas.Password = thisUser.Passcode;

        }

        private void btnNewCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (statusPage == StatusPage.Add)
            {
                thisUser = new ServiceClient.Castumer();
                FillObg();
                Global.proxy.AddCustomerAsync(thisUser);
            }
            else
            {
                Global.proxy.UpdateCustomerAsync(thisUser);
            }

            this.Frame.Navigate(typeof(MainPage));
        }

        private void FillObg()
        {
            thisUser.ID =Convert.ToInt32( numAd.Text);
            thisUser.FirstName = nameCas.Text;
            thisUser.LastName = lastnameCas.Text;
            thisUser.Phone= Convert.ToInt32(phone.Text);
            thisUser.Mail = email.Text;
            thisUser.BirthDate = Convert.ToDateTime( DateBD.Date.Value.Date);
            thisUser.SizeShoes = Convert.ToInt32(shoesSize.Text);
            thisUser.High = Convert.ToInt32 ( heightCas.Text);
            thisUser.Weight = Convert.ToInt32 (wightCas.Text);
            thisUser.Passcode = passwordCas.Password;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }
    }
}
