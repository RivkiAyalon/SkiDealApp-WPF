﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ClientApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPageGuide : Page
    {
        public MainPageGuide()
        {
            this.InitializeComponent();
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            txtGuideName.Text = Global.currentGuide.NameGuide;
            txtNameGuide.Text = Global.currentGuide.NameGuide;
            txtLegionGuide.Text = Global.currentGuide.legion;
            txtPhoneGuide.Text = Global.currentGuide.Phone.ToString();
            txtMailGuide.Text = Global.currentGuide.Mail;
            txtDayWorkGuide.Text = Global.currentGuide.NameGuide;

            lbHourGuide.ItemsSource = await Global.proxy.GetDaysWorkForGuideAsync(Global.currentGuide);
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }

        private void hours_Click(object sender, RoutedEventArgs e)
        {
            newDayWork.Visibility = Visibility.Visible;
        }

        private void updateDays_Click(object sender, RoutedEventArgs e)
        {
            //ServiceClient.hoursGuide hg;
            //if (sunday.IsChecked.Value == true)
            //{
            //    hg += 1;
            //    Global.proxy.AddhoursGuideAsync(hg);
            //}

            //if (monday.IsChecked.Value == true)
            //{
            //    hg += 1;
            //    Global.proxy.AddhoursGuideAsync(hg);
            //}
            //if (tusday.IsChecked.Value == true)
            //{
            //    hg += 1;
            //    Global.proxy.AddhoursGuideAsync(hg);
            //}
            //if (wodensday.IsChecked.Value == true)
            //{
            //    hg += 1;
            //    Global.proxy.AddhoursGuideAsync(hg);
            //}
            //if (thirsday.IsChecked.Value == true)
            //{
            //    hg += 1;
            //    Global.proxy.AddhoursGuideAsync(hg);
            //}
            //if (friday.IsChecked.Value == true)
            //{
            //    hg += 1;
            //    Global.proxy.AddhoursGuideAsync(hg);
            //}
            this.Frame.Navigate(typeof(LoginPage));

        }
    }
}
