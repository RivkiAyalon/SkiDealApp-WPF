﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Sockets;

namespace ClientApp
{
    public static class Global
    {

        public static ServiceClient.ClientClient proxy = new ServiceClient.ClientClient();
        public static ServiceClient.Castumer currentCustomer;
        public static ServiceClient.Guide currentGuide;
        public static ServiceClient.Subscribe currentsub;
        public static ServiceClient.CategoryEquipment catEui;
        
        
        
    }
}
