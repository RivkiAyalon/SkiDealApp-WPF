﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace ClientApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        ServiceClient.LogInToTheSite thisUserlog;
        StatusPage statusPage;
        public MainPage()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);


            if (e.Parameter == null)
                statusPage = StatusPage.Add;
            else
            {
                thisUserlog = e.Parameter as ServiceClient.LogInToTheSite;
                FillFromFields();
            }

        }
        private void FillFromFields()
        {
            
            //IdCustumer
            //    Guide
            //    Date1

        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

            
            if (Global.currentCustomer != null&& Global.currentsub!=null)
            {
                txtUserName.Text = Global.currentCustomer.FirstName + " " + Global.currentCustomer.LastName;
                txtidsub.Text = Global.currentCustomer.ID.ToString();
                txtfromsub.Text = Global.currentsub.fromDate.Date.ToString();
                txttilsub.Text = Global.currentsub.untilDate.Date.ToString();
                txtguidesub.Text = Global.currentsub.Guide.ToString();
                txtquisub.Text = Global.currentsub.Equipmentrental.ToString();

            }

        }

        private void btnNewSubscribe_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(newSubscribe));
        }

        private async void btnIsSubscribe_Click(object sender, RoutedEventArgs e)
        {
            if (Global.proxy.GetSubscribeByCustomerAsync(Global.currentCustomer) != null) { 
            ServiceClient.Subscribe subscrib = await Global.proxy.GetSubscribeByCustomerAsync(Global.currentCustomer);
                Global.currentsub = subscrib;
            if (subscrib!=null)
            {

                SubscribeItems.Visibility = Visibility.Visible;
            }
            else
                NoSubscribe.Visibility = Visibility.Visible;
            }
            if (Global.currentCustomer != null && Global.currentsub != null)
            {
                txtUserName.Text = Global.currentCustomer.FirstName + " " + Global.currentCustomer.LastName;
                txtidsub.Text = Global.currentCustomer.ID.ToString();
                txtfromsub.Text = Global.currentsub.fromDate.Date.ToString();
                txttilsub.Text = Global.currentsub.untilDate.Date.ToString();
                txtguidesub.Text = Global.currentsub.Guide.ToString();
                txtquisub.Text = Global.currentsub.Equipmentrental.ToString();

            }

        }

        private void btnInvite_Click(object sender, RoutedEventArgs e)
        {         
                if (statusPage == StatusPage.Add)
                {
                    thisUserlog = new ServiceClient.LogInToTheSite();
                    FillObg();
                    Global.proxy.AddLogInToTheSiteAsync(thisUserlog);
                }
                else
                {
                    Global.proxy.UpdateLogInToTheSiteAsync(thisUserlog);
                }

                this.Frame.Navigate(typeof(Finaly));        
        }
        private void FillObg()
        {
            thisUserlog.IdCustumer = Global.currentCustomer;
            thisUserlog.fromtime= DateTime.Now;
            thisUserlog.untiltime = DateTime.Now.AddHours(5);
            thisUserlog.Date1 = DateTime.Today;
        
        }
        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }

        private void btnUPCAS_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(BlankPage1), (ServiceClient.Castumer)(sender as Button).DataContext);
        }

        private void btnUpSub_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(newSubscribe), (ServiceClient.Subscribe)(sender as Button).DataContext);
        }

        /*private void btnIsSubscribe_Click(object sender, RoutedEventArgs e)
        {
           
        }
        */
    }
}
