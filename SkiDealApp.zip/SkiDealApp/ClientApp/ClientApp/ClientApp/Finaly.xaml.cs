﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ClientApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Finaly : Page
    {

        public Finaly()
        {
            this.InitializeComponent();
        }

        private void btnChooseE_Click(object sender, RoutedEventArgs e)
        {
            ifEqui.Visibility = Visibility.Visible;
        }


        private async void btnbtnFinal_Click(object sender, RoutedEventArgs e)
        {
            //ServiceClient.skiEquipment equipment;
            ////לכתוב שהציוד יהיה תפוס==false
            //if (ChooseK.IsChecked.Value == true)
            //{
            //    equipment = await Global.proxy.GetSkiEquipmentByCateroryAsync(1, Global.currentCustomer);
            //    equipment.Free = false;
            //    await Global.proxy.UpdateskiEquipmentAsync(equipment);

            //}
            //if (ChooseS.IsChecked.Value == true)
            //{
            //    equipment = await Global.proxy.GetSkiEquipmentByCateroryAsync(4, Global.currentCustomer);
            //    equipment.Free = false;
            //    await Global.proxy.UpdateskiEquipmentAsync(equipment);
            //}
            //if (ChooseM.IsChecked.Value == true)
            //{
            //    equipment = await Global.proxy.GetSkiEquipmentByCateroryAsync(2, Global.currentCustomer);
            //    equipment.Free = false;
            //    await Global.proxy.UpdateskiEquipmentAsync(equipment);
            //}
            //if (ChooseMK.IsChecked.Value == true)
            //{
            //    equipment = await Global.proxy.GetSkiEquipmentByCateroryAsync(3, Global.currentCustomer);
            //    equipment.Free = false;
            //    await Global.proxy.UpdateskiEquipmentAsync(equipment);
            //}
              
            finalF.Visibility = Visibility.Visible;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }
    }
}
