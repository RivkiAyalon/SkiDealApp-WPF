﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ClientApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class newSubscribe : Page
    {
        ServiceClient.Subscribe thisUser;
        StatusPage statusPage;

        int price=1000;
        public newSubscribe()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            numAd.Text = Global.currentCustomer.ID.ToString();
            textsum.Text = price.ToString();

            if (e.Parameter == null)
                statusPage = StatusPage.Add;
            else
            {
                statusPage = StatusPage.Update;
                thisUser = e.Parameter as ServiceClient.Subscribe;
                FillFromFields();
            }

        }
        private void FillFromFields()
        {
          
            numAd.Text = thisUser.IdCustumer.ToString();
            fromDate.Date = thisUser.fromDate;
            untilDate.Date = thisUser.untilDate;
            //isGuide.= thisUser.Guide;
            //isEquipment. = thisUser.Equipmentrental;

        }

        private void btnNewCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (statusPage == StatusPage.Add)
            {
                thisUser = new ServiceClient.Subscribe();
                FillObg();
                Global.proxy.AddSubscribeAsync(thisUser);
            }
            else
            {
                FillObg();
                Global.proxy.UpdateSubscribeAsync(thisUser);
            }

            this.Frame.Navigate(typeof(MainPage));
        }
        private void FillObg()
        {
            thisUser.IdCustumer =Global.currentCustomer;
            thisUser.fromDate= Convert.ToDateTime(fromDate.Date.Value.Date);
            thisUser.untilDate = Convert.ToDateTime(untilDate.Date.Value.Date);
            thisUser.Guide =isGuide.IsChecked.Value;
            thisUser.Equipmentrental = isEquipment.IsChecked.Value;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {
            textsum.Text = "1000";
            if (isGuide.IsChecked.Value == true&& isEquipment.IsChecked.Value==true)
                textsum.Text = "2500";
            else if(isGuide.IsChecked.Value == true)
                textsum.Text = "1500";
            else
                textsum.Text = "2000";
        }

        private void isGuide_Checked(object sender, RoutedEventArgs e)
        {
            price += 500;
            textsum.Text=price.ToString();
        }

        private void isEquipment_Checked(object sender, RoutedEventArgs e)
        {
            price += 1000;
            textsum.Text = price.ToString();
        }
    }
}
