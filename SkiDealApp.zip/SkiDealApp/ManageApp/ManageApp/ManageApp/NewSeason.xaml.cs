﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ManageApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class NewSeason : Page
    {
        ManagerService.SkiSeason thisUser;
        StatusPage statusPage;
        public NewSeason()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);


            if (e.Parameter == null)
                statusPage = StatusPage.Add;
            else
            {
                statusPage = StatusPage.Update;
                thisUser = e.Parameter as ManagerService.SkiSeason;
                FillFromFields();
            }

        }
        private void FillFromFields()
        {
           
            nameS.Text = thisUser.NameSeason;
            from.Date = thisUser.fromdate;
            until.Date = thisUser.untildate;
            
        }
        

        private void btnNewSeason_Click(object sender, RoutedEventArgs e)
        {
            news.Visibility = Visibility.Visible;
        }

        private void btnshowSeason_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(showSeason));
        }

        private void btnNewSeason2_Click(object sender, RoutedEventArgs e)
        {
            if (statusPage == StatusPage.Add)
            {
                thisUser = new ManagerService.SkiSeason();
                FillObg();
                Global.proxy.AddSkiSeasonAsync(thisUser);
            }
            else
            {
                Global.proxy.UpdateSkiSeasonAsync(thisUser);
            }

            this.Frame.Navigate(typeof(MainPage));
        }
        private void FillObg()
        {
         
            thisUser.NameSeason = nameS.Text;
            thisUser.fromdate = Convert.ToDateTime(from.Date.Value.Date);
            thisUser.untildate = Convert.ToDateTime(until.Date.Value.Date);

        }

       

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }
    }
}
