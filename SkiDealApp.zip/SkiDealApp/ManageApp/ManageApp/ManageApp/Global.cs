﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageApp
{
    public static class Global
    {
        public static ManagerService.Service1Client proxy= new ManagerService.Service1Client();
        public static ManagerService.Castumer currentc;
        public static ManagerService.Subscribe currents;
        public static ManagerService.Guide currentg;
        public static ManagerService.skiEquipment currente;
        public static ManagerService.SkiSeason currentse;

    }
}
