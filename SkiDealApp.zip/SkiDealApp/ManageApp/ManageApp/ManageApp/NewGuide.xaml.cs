﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ManageApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class NewGuide : Page
    {
        ManagerService.Guide thisUser;
        StatusPage statusPage;
        public NewGuide()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);


            if (e.Parameter == null)
                statusPage = StatusPage.Add;
            else
            {
                statusPage = StatusPage.Update;
                thisUser = e.Parameter as ManagerService.Guide;
                FillFromFields();
            }

        }
        private void FillFromFields()
        {
            idGuide.Text = thisUser.IdGuide.ToString();
            nameGuide.Text = thisUser.NameGuide;
            Gender.Text = thisUser.legion;
            phone.Text = thisUser.Phone.ToString();
            male.Text = thisUser.Mail;

        }
        private void btnNewGuide_Click(object sender, RoutedEventArgs e)
        {
            if (statusPage == StatusPage.Add)
            {
                thisUser = new ManagerService.Guide();
                FillObg();
                Global.proxy.AddGuideAsync(thisUser);
            }
            else
            {
                FillObg();
                Global.proxy.UpdateGuideAsync(thisUser);
            }

            this.Frame.Navigate(typeof(MainPage));
        }
        private void FillObg() {
            thisUser.IdGuide = Convert.ToInt32(idGuide.Text);
            thisUser.NameGuide = nameGuide.Text;
            thisUser.legion = Gender.Text;
            thisUser.Phone = Convert.ToInt32(phone.Text);
            thisUser.Mail = male.Text;

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }
    }
}
