﻿using ManageApp.ManagerService;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ManageApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class returnEqui : Page
    {
        public returnEqui()
        {
            this.InitializeComponent();
        }

        private async void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            ManagerService.skiEquipment equipment = (ManagerService.skiEquipment)(sender as Button).DataContext;
            List<ManagerService.DetailsRent> detailsRents = await Global.proxy.GetDetailsRentAsync();
            ManagerService.DetailsRent detailsRent = detailsRents.LastOrDefault(x => x.CodeEquipment.CodeEquipment == equipment.CodeEquipment);
            detailsRent.Return2 = true;

            await Global.proxy.UpdateDetailsRentAsync(detailsRent);

            this.Frame.GoBack();
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            showEquipments.ItemsSource = await Global.proxy.GetskiEquipmentAsync();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }
    }
}
