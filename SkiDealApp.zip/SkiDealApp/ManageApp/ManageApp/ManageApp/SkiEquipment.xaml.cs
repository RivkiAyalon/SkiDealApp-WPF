﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ManageApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>

    
    public sealed partial class SkiEquipment : Page
    {
        ManagerService.skiEquipment thisUser;
        StatusPage statusPage;
        public SkiEquipment()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);


            if (e.Parameter == null)
                statusPage = StatusPage.Add;
            else
            {
                thisUser = e.Parameter as ManagerService.skiEquipment;
                FillFromFields();
            }

        }
        private void FillFromFields()
        {
            
            nameE.Text = thisUser.NameEquipment;
            categoryE.Text = thisUser.Category.ToString();
            sizeE.Text = thisUser.Size.ToString();
            //right.Text = thisUser.Right.ToString();
            //free.Text = thisUser.Free.ToString();

        }
        

        private void btnshowEquipment_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(showEquipment));
        }

        private void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(returnEqui));
        }

       

        private void btnNewEquipment_Click(object sender, RoutedEventArgs e)
        {
            newE.Visibility = Visibility.Visible;
        }

      

        private void btnNewEquipment2_Click(object sender, RoutedEventArgs e)
        {
            if (statusPage == StatusPage.Add)
            {
                thisUser = new ManagerService.skiEquipment();
                FillObg();
                Global.proxy.AddskiEquipmentAsync(thisUser);    
            }
            else
            {
                FillObg();
                Global.proxy.UpdateskiEquipmentAsync(thisUser);
            }

            this.Frame.Navigate(typeof(MainPage));
        }
        private void FillObg()
        {
           
            thisUser.NameEquipment = nameE.Text;
            //thisUser.Category = categoryE;
            thisUser.Size = Convert.ToInt32(sizeE.Text);
             thisUser.Right= right.IsChecked.Value;
            thisUser.Free = free.IsChecked.Value;

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }
    }
}
